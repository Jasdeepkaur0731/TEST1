package com.example.sandhu_supermarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SandhuSupermarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(SandhuSupermarketApplication.class, args);
	}

}
